# Unity-Platformer-Episode-15
In this episode we'll add the ability to pause the game and a pause menu with some cool options like changing the volume of the sounds and music. We'll also discuss regions and PlayerPrefs.
https://www.youtube.com/watch?v=2pk1PPlS5Xs&ab_channel=Pandemonium

➤ Support the channel on Patreon: https://www.patreon.com/pandemonium_games
